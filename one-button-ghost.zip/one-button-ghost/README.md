# Ghost Hop — Elaine

A one-button, pixel-art game made with p5.js. A little ghost travels through a purple castle landscape and jumps over gravestones.

## Play

Open this entire folder in VS Code. Right-click `index.html` and select **Open with Live Server**. All scripts are bundled locally; there are no packages to install for the game.

Alternatively, run `python3 -m http.server 8768` in this folder and visit `http://localhost:8768`. Direct file opening was not verified because the test browser blocks file URLs.

Press **Space**, click the game, or use its single button. These are alternative inputs for the same action, not different controls.

- First press: start.
- During play: jump, only when on the ground. Holding Space does not repeat jumps.
- Clear a gravestone: earn one point. The speed gradually increases, with a limit.
- Hit a gravestone: game over. Press again to restart; a short delay prevents accidental restarts.
- Switching away pauses the game. Press once to resume.
- BEST lasts for the current page session. Reloading resets it.

## Code

- `game.js`: the `Game` class handles state, jump velocity, gravity, obstacles, collisions, and score.
- `sketch.js`: p5.js draws the pixel ghost and background, connects all inputs to `game.action()`, and updates the interface.
- `index.html` and `style.css`: page layout and styles.
- `libraries`: p5.js and its license. Keep this folder with the other files.

The game has three states: `ready`, `playing`, and `over`. A separate pause flag freezes play. The physics advances in small fixed time steps. Obstacles move left to create forward movement; collision checks use slightly smaller rectangles than the artwork. The ghost is drawn with nested loops over an array of character strings.

## Assignment scope and AI assistance

The confirmed assignment description was a one-button game. Additional teacher requirements, deadline, and submission format have not been provided. This implementation uses p5.js, following the language used in earlier coursework; it has not been checked against a new formal rubric.

Codex helped design, write, and test this project. The approved idea was a ghost that automatically travels forward, jumps with one button, scores points for dodging obstacles, and restarts with the same button. Review and understand the code before submitting.

All game artwork is drawn in code. The p5.js library is copied from the earlier coursework project; its original package URL was tagged 2.3.3, while its internal version string reports 2.3.1. The license is included.

## Checks

Optional developer tests: `node --test tests/game.test.cjs` (Node.js is not needed to play).

The tests cover jumping, landing, collision, scoring, restarting, pausing, and a simulated five-minute run. Browser checks confirmed the start screen, button start, collision/game-over message, Space restart, visible jump, and no console errors. The five-minute run is a simulation, not a five-minute manual play session. Touch input is implemented but has not been tested on a physical phone.
