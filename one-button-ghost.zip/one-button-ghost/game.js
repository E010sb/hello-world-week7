class Game {
  constructor() {
    this.state = "ready";
    this.best = 0;
    this.reset();
  }

  reset() {
    this.score = 0;
    this.ghost = { x: 120, y: 294, width: 32, height: 32, velocity: 0 };
    this.obstacles = [{ x: 600, width: 28, height: 36, scored: false }];
    this.spawnTimer = 1.8;
    this.distance = 0;
    this.paused = false;
    this.restartDelay = 0;
  }

  action() {
    if (this.paused) {
      this.paused = false;
    } else if (this.state !== "playing") {
      if (this.restartDelay > 0) return;
      this.reset();
      this.state = "playing";
    } else if (this.ghost.y >= 294) {
      this.ghost.velocity = -510;
    }
  }

  update(dt) {
    this.restartDelay = Math.max(0, this.restartDelay - dt);
    if (this.state !== "playing" || this.paused) return;

    const speed = Math.min(240 + this.score * 5, 370);
    this.distance += speed * dt;
    this.ghost.velocity += 1400 * dt;
    this.ghost.y += this.ghost.velocity * dt;
    if (this.ghost.y >= 294) {
      this.ghost.y = 294;
      this.ghost.velocity = 0;
    }

    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      this.obstacles.push({ x: 820, width: 24 + Math.floor(Math.random() * 13), height: 28 + Math.floor(Math.random() * 19), scored: false });
      this.spawnTimer = 1.4 + Math.random() * 0.5;
    }

    for (const obstacle of this.obstacles) {
      obstacle.x -= speed * dt;
      if (this.hits(obstacle)) {
        this.state = "over";
        this.restartDelay = 0.4;
        this.best = Math.max(this.best, this.score);
        return;
      }
      if (!obstacle.scored && obstacle.x + obstacle.width < this.ghost.x) {
        obstacle.scored = true;
        this.score++;
        this.best = Math.max(this.best, this.score);
      }
    }
    this.obstacles = this.obstacles.filter(obstacle => obstacle.x + obstacle.width > 0);
  }

  hits(obstacle) {
    const ghost = this.ghost;
    return ghost.x + 5 < obstacle.x + obstacle.width - 3 &&
      ghost.x + ghost.width - 5 > obstacle.x + 3 &&
      ghost.y + ghost.height - 3 > 326 - obstacle.height + 3;
  }
}

if (typeof module !== "undefined") module.exports = Game;
