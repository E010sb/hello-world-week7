const game = new Game();
let elapsed = 0;
let previousUI = "";
const ghostPixels = [
  "..WWWW..",
  ".WWWWWW.",
  "WWWWWWWW",
  "WWDWWDWW",
  "WWDWWDWW",
  "WPWWWWPW",
  "WWWWWWWW",
  "WW.WW.WW"
];

function setup() {
  const canvas = createCanvas(800, 420);
  canvas.parent("stage");
  pixelDensity(1);
  noSmooth();
  noStroke();
  textFont("Courier New");
  canvas.elt.addEventListener("pointerdown", event => {
    if (event.button !== 0) return;
    event.preventDefault();
    game.action();
  });
  document.getElementById("action").onclick = () => game.action();
  window.addEventListener("keydown", event => {
    if (event.code === "Space") {
      event.preventDefault();
      if (!event.repeat) game.action();
    }
  });
  window.addEventListener("blur", pauseGame);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) pauseGame();
  });
}

function pauseGame() {
  if (game.state === "playing") game.paused = true;
  elapsed = 0;
}

function draw() {
  elapsed += min(deltaTime / 1000, 0.1);
  while (elapsed >= 1 / 60) {
    game.update(1 / 60);
    elapsed -= 1 / 60;
  }
  drawNight();
  for (const obstacle of game.obstacles) drawGravestone(obstacle);
  drawGhost();

  if (game.state !== "playing" || game.paused) {
    fill("#241933");
    rect(225, 93, 350, 96);
    fill("#eee4ff");
    textAlign(CENTER, CENTER);
    textSize(28);
    text(game.paused ? "TAKE A BREATHER" : game.state === "ready" ? "A LITTLE LEAP" : "BOO! TRY AGAIN", 400, 126);
    fill("#c8a6e5");
    textSize(14);
    text(game.paused ? "PRESS SPACE TO RESUME" : game.state === "ready" ? "PRESS SPACE TO START" : "PRESS SPACE TO RESTART", 400, 161);
  }
  updateUI();
}

function drawNight() {
  background("#211832");
  for (let i = 0; i < 32; i++) {
    fill(i % 3 === 0 ? "#dcc2ec" : "#705981");
    rect((i * 97 + 29) % 790, (i * 47 + 23) % 215, 3, 3);
  }
  fill("#e4cef1");
  rect(660, 42, 48, 40);
  rect(668, 34, 32, 56);
  fill("#211832");
  rect(682, 30, 32, 46);

  for (let i = 0; i < 9; i++) {
    const x = i * 120 - (game.distance * 0.15) % 120;
    const towerHeight = 75 + (i % 3) * 25;
    fill("#30233f");
    rect(x, 326 - towerHeight, 76, towerHeight);
    for (let top = 0; top < 3; top++) rect(x + top * 28, 316 - towerHeight, 20, 12);
    fill("#513b65");
    rect(x + 30, 350 - towerHeight, 12, 20);
  }
  fill("#b394ce");
  rect(0, 326, 800, 4);
  fill("#382749");
  rect(0, 330, 800, 90);
  for (let i = 0; i < 24; i++) {
    fill("#644878");
    rect(i * 40 - game.distance % 40, 342, 20, 4);
    fill("#49315c");
    rect(i * 40 + 10 - game.distance % 40, 373, 8, 4);
  }
}

function drawGhost() {
  const palette = { W: "#f6edff", D: "#38214e", P: "#d29bda" };
  for (let y = 0; y < ghostPixels.length; y++) {
    for (let x = 0; x < ghostPixels[y].length; x++) {
      const shade = palette[ghostPixels[y][x]];
      if (shade) {
        fill(shade);
        rect(game.ghost.x + x * 4, Math.round(game.ghost.y) + y * 4, 4, 4);
      }
    }
  }
}

function drawGravestone(obstacle) {
  const x = Math.round(obstacle.x);
  const y = 326 - obstacle.height;
  fill("#aa87c3");
  rect(x, y + 5, obstacle.width, obstacle.height - 5);
  rect(x + 4, y, obstacle.width - 8, 5);
  fill("#72528a");
  rect(x + obstacle.width - 5, y + 5, 5, obstacle.height - 5);
  fill("#382749");
  rect(x + obstacle.width / 2 - 2, y + 10, 4, 17);
  rect(x + obstacle.width / 2 - 6, y + 15, 12, 4);
}

function updateUI() {
  const key = `${game.state}-${game.paused}-${game.score}-${game.best}`;
  if (key === previousUI) return;
  previousUI = key;
  document.getElementById("score").textContent = String(game.score).padStart(2, "0");
  document.getElementById("best").textContent = String(game.best).padStart(2, "0");
  document.getElementById("action").textContent = game.paused ? "RESUME" : game.state === "ready" ? "START" : game.state === "over" ? "TRY AGAIN" : "JUMP";
  document.getElementById("message").textContent = game.paused ? "Paused. Your ghost is safe." : game.state === "ready" ? "One little ghost. One button. How far can you go?" : game.state === "over" ? `You cleared ${game.score} gravestones. One more try?` : "Tap to jump. Clear a gravestone to earn a point.";
}
