const test = require("node:test");
const assert = require("node:assert/strict");
const Game = require("../game.js");

function advance(game, frames) {
  for (let i = 0; i < frames; i++) game.update(1 / 60);
}

test("one action starts; another jumps; airborne presses do not double-jump", () => {
  const game = new Game();
  assert.equal(game.state, "ready");
  game.action();
  assert.equal(game.state, "playing");
  game.action();
  advance(game, 10);
  assert.ok(game.ghost.y < 294);
  const velocity = game.ghost.velocity;
  game.action();
  assert.equal(game.ghost.velocity, velocity);
  advance(game, 40);
  assert.equal(game.ghost.y, 294);
});

test("collision ends play; restart delay prevents accidental restart", () => {
  const game = new Game();
  game.action();
  for (let i = 0; i < 180 && game.state === "playing"; i++) game.update(1 / 60);
  assert.equal(game.state, "over");
  game.action();
  assert.equal(game.state, "over");
  advance(game, 25);
  game.action();
  assert.equal(game.state, "playing");
  assert.equal(game.score, 0);
});

test("pause freezes obstacles and the same action resumes", () => {
  const game = new Game();
  game.action();
  game.paused = true;
  const before = JSON.stringify(game.obstacles);
  advance(game, 60);
  assert.equal(JSON.stringify(game.obstacles), before);
  game.action();
  assert.equal(game.paused, false);
});

test("each cleared obstacle scores once; restart retains the session best", () => {
  const game = new Game();
  game.action();
  game.obstacles = [{ x: 80, width: 28, height: 36, scored: false }];
  advance(game, 3);
  assert.equal(game.score, 1);
  game.obstacles = [{ x: 120, width: 28, height: 36, scored: false }];
  advance(game, 1);
  assert.equal(game.state, "over");
  advance(game, 25);
  game.action();
  assert.equal(game.score, 0);
  assert.equal(game.best, 1);
});

test("a timed jump strategy clears a simulated five-minute run", () => {
  const game = new Game();
  game.action();
  for (let frame = 0; frame < 18000; frame++) {
    const next = game.obstacles.find(obstacle => obstacle.x + obstacle.width > game.ghost.x);
    const speed = Math.min(240 + game.score * 5, 370);
    if (next && next.x - game.ghost.x < speed * 0.24 && game.ghost.y === 294) game.action();
    game.update(1 / 60);
    assert.equal(game.state, "playing");
  }
  assert.ok(game.score > 100);
});
